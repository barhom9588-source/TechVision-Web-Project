# TechVision — مشروع مقرر تصميم الويب

## التشغيل
1. فك الضغط.
2. افتح المجلد في VS Code أو Acode.
3. شغّل `index.html`.
4. للحصول على تجربة AJAX كاملة شغّل المشروع بواسطة Live Server أو أي Local Server، لأن بعض المتصفحات تمنع قراءة `data.json` عند فتح الملف مباشرة.

## الملفات
- `index.html` : هيكل الصفحة.
- `css/style.css` : التصميم، Grid/Flexbox وMedia Queries.
- `js/script.js` : السلايدر، التحقق من النموذج، Toast، Modal وAJAX.
- `data.json` : البيانات التي يتم تحميلها بواسطة AJAX.
- `images/` : مجلد جاهز لإضافة صور المشروع.

## المتطلبات المطبقة
1. مجلد مستقل للمشروع.
2. HTML Layout: header, nav, main, section, aside, footer.
3. عناصر HTML: عناوين، فقرات، قوائم، جدول، نموذج.
4. Font Awesome.
5. إنشاء الحساب/تسجيل الدخول + Validation.
6. شريط صور متحرك بأسلوب WowSlider.
7. CSS Grid وFlexbox.
8. Responsive باستخدام Media Queries.
9. Toast Notification.
10. Modal مع AJAX.
11. Bootstrap.
12. jQuery.
13. جاهز للرفع على GitHub.
14. مناسب كنموذج تطبيقي لمتطلبات دورة Kevin Powell.

## ملاحظة عن WowSlider
السلايدر داخل المشروع مكتوب بطريقة خفيفة بالـHTML/CSS/jQuery ويحمل وظيفة WowSlider المطلوبة (صور متحركة، أزرار، نقاط، تشغيل تلقائي). إذا كان الدكتور يشترط برنامج WowSlider الأصلي تحديداً، يمكن استبدال هذا الجزء بملفات WowSlider التي يتم توليدها من البرنامج.
