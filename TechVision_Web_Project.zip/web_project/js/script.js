$(function () {
  // =========================
  // WowSlider-style carousel
  // =========================
  const slides = $('.slide');
  const dotsBox = $('.dots');
  let current = 0;
  let timer;

  slides.each(function (i) {
    dotsBox.append(`<span class="dot ${i === 0 ? 'active' : ''}" data-index="${i}"></span>`);
  });

  function showSlide(index) {
    current = (index + slides.length) % slides.length;
    slides.removeClass('active').eq(current).addClass('active');
    $('.dot').removeClass('active').eq(current).addClass('active');
  }

  $('.slider-btn.prev').on('click', () => showSlide(current - 1));
  $('.slider-btn.next').on('click', () => showSlide(current + 1));
  $('.dot').on('click', function () {
    showSlide(Number($(this).data('index')));
  });

  function startSlider() {
    timer = setInterval(() => showSlide(current + 1), 4500);
  }
  startSlider();

  $('.wowslider').on('mouseenter', () => clearInterval(timer));
  $('.wowslider').on('mouseleave', startSlider);

  // =========================
  // Form Validation
  // =========================
  function setError(id, message) {
    $('#' + id).addClass('input-error');
    $('#' + id + 'Error').text(message);
  }

  function clearError(id) {
    $('#' + id).removeClass('input-error');
    $('#' + id + 'Error').text('');
  }

  $('#contactForm').on('submit', function (e) {
    e.preventDefault();

    const name = $('#name').val().trim();
    const email = $('#email').val().trim();
    const subject = $('#subject').val().trim();
    const message = $('#message').val().trim();
    let valid = true;

    ['name', 'email', 'subject', 'message'].forEach(clearError);

    if (name.length < 3) {
      setError('name', 'الاسم يجب أن يكون 3 أحرف على الأقل.');
      valid = false;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError('email', 'أدخل بريداً إلكترونياً صحيحاً.');
      valid = false;
    }
    if (subject.length < 3) {
      setError('subject', 'اكتب موضوع الرسالة.');
      valid = false;
    }
    if (message.length < 10) {
      setError('message', 'الرسالة يجب أن تكون 10 أحرف على الأقل.');
      valid = false;
    }

    if (!valid) return;

    // Toast Notification
    const toast = bootstrap.Toast.getOrCreateInstance(document.getElementById('successToast'));
    toast.show();
    this.reset();
  });

  // =========================
  // AJAX -> Modal
  // =========================
  $('#infoModal').on('show.bs.modal', function () {
    const modalBody = $('#ajaxContent');
    modalBody.html('<div class="text-center"><div class="spinner-border" role="status"></div><p class="mt-2">جاري تحميل البيانات...</p></div>');

    // AJAX request using a local JSON endpoint/file.
    $.ajax({
      url: 'data.json',
      dataType: 'json',
      timeout: 3000
    }).done(function (data) {
      modalBody.html(`
        <h6 class="fw-bold">${data.title}</h6>
        <p>${data.description}</p>
        <ul>${data.points.map(p => `<li>${p}</li>`).join('')}</ul>
      `);
    }).fail(function () {
      // Helpful when opening index.html directly without a local server.
      modalBody.html(`
        <h6 class="fw-bold">المشروع جاهز</h6>
        <p>تم تجهيز عناصر المشروع المطلوبة من HTML وCSS وJavaScript وBootstrap وjQuery.</p>
        <p class="mb-0">لتجربة AJAX بشكل كامل شغّل الموقع عبر Live Server أو أي خادم محلي.</p>
      `);
    });
  });

  // Login form demo
  $('#loginForm').on('submit', function (e) {
    e.preventDefault();
    bootstrap.Modal.getInstance(document.getElementById('loginModal')).hide();
    bootstrap.Toast.getOrCreateInstance(document.getElementById('successToast')).show();
  });
});
